#ifndef HEADER_Battery
#define HEADER_Battery

void Battery_getData(double* level, ACPresence* isOnAC);

#endif
